from flask import Flask, render_template, jsonify, request, session, redirect
import sqlite3
import database_operations as dbop


app = Flask(__name__)
app.secret_key = "fantasy_league"
DATABASE_PATH = 'fantasy.db'


def dict_factory(cursor, row):
    d = {}
    for idx, col in enumerate(cursor.description):
        d[col[0]] = row[idx]
    return d


def create_connection(db_file):
    conn = None
    try:
        conn = sqlite3.connect(db_file)
    except Error as e:
        print(e)
    return conn


def create_tables():
    user_table = """
        CREATE TABLE IF NOT EXISTS user(
            user_ID INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT,
            password TEXT,
            activated INTEGER DEFAULT 0,
            points REAL DEFAULT 0.0,
            deleted INTEGER DEFAULT 0,
            current_bet_ID DEFAULT NULL 
        )
    """
    team_table = """
        CREATE TABLE IF NOT EXISTS team(
            team_ID INTEGER PRIMARY KEY AUTOINCREMENT,
            team_name TEXT,
            team_code TEXT
        )
    """

    team_members_table = """
        CREATE TABLE IF NOT EXISTS team_member(
            member_ID INTEGER PRIMARY KEY AUTOINCREMENT,
            member_name TEXT,
            photo_link TEXT,
            team_ID INTEGER REFERENCES team(team_ID)
        )
    """

    ipl_schedule_table = """
        CREATE TABLE IF NOT EXISTS ipl_schedule(
            schedule_ID INTEGER PRIMARY KEY AUTOINCREMENT,
            team1_ID INTEGER REFERENCES team(team_ID),
            team2_ID INTEGER REFERENCES team(team_ID),
            scheduled_date DATETIME,
            deadline DATETIME
        )
    """

    ipl_scheduled_points_table = """
        CREATE TABLE IF NOT EXISTS ipl_scheduled_points(
            ISP_ID INTEGER PRIMARY KEY AUTOINCREMENT,
            schedule_ID INTEGER REFERENCES ipl_schedule(schedule_ID),
            member_ID INTEGER REFERENCES team_member(member_ID),
            points REAL DEFAULT 0.0
        )
    """

    bet_table = """
        CREATE TABLE IF NOT EXISTS bet(
            bet_ID INTEGER PRIMARY KEY AUTOINCREMENT,
            user_ID INTEGER REFERENCES user(user_ID),
            schedule_ID INTEGER REFERENCES ipl_schedule(schedule_ID),
            for_team_ID INTEGER REFERENCES team(team_ID),
            placed_at DATETIME,
            points_won REAL DEFAULT 0.0
        )
    """

    bet_on_person_table = """
        CREATE TABLE IF NOT EXISTS bet_on_person(
            bp_ID INTEGER PRIMARY KEY AUTOINCREMENT,
            bet_ID INTEGER REFERENCES bet(bet_ID),
            member_id INTEGER REFERENCES team_member(member_ID)
        )
    """
    conn = create_connection(DATABASE_PATH)
    conn.row_factory = dict_factory
    c = conn.cursor()
    c.execute(user_table)
    c.execute(team_table)
    c.execute(team_members_table)
    c.execute(ipl_schedule_table)
    c.execute(ipl_scheduled_points_table)
    c.execute(bet_table)
    c.execute(bet_on_person_table)
    conn.commit()
    conn.close()

create_tables()
@app.route('/')
def login_page():
    return render_template('index.html')


@app.route('/signup')
def signup_page():
    return render_template('signup.html')

@app.route('/home')
def home_page():
    if "user_id" not in session:
        return render_template("index.html")
    return render_template('home.html')

@app.route('/bet')
def bet_page():
    if "user_id" not in session:
        return render_template("index.html")
    return render_template('bet.html')

@app.route('/logout')
def logout():
    session.clear()
    return redirect('/')
######AJAX CALLS#########
@app.route("/login_ajax", methods=['POST'])
def login_user():
    data = request.get_json()
    print(data['username'], data['password'])
    resp = dbop.check_login(data)
    if resp['status_code'] == 200:
        session['user_id'] = resp['user_id']
        session['username'] = resp['username']
    return jsonify(resp)

@app.route("/signup_ajax", methods=['POST'])
def signup_user():
    data = request.get_json()
    resp = dbop.signup_user(data)
    return jsonify(resp)

@app.route('/home_ajax', methods=['POST'])
def home_ajax():
    resp = dbop.get_home_data(session['user_id'])
    return jsonify(resp)

@app.route('/verify_bet_ajax', methods=['POST'])
def verify_bet_ajax():
    data = request.get_json()
    resp = dbop.verify_bet_ajax(session['user_id'], data['schedule_id'])
    return jsonify(resp)

@app.route('/get_players_ajax', methods=['POST'])
def get_players_ajax():
    data = request.get_json()
    resp = dbop.get_players(session['user_id'], data['team_code'])
    return jsonify(resp)

@app.route('/place_bet_ajax', methods=['POST'])
def place_bet_ajax():
    print(session)
    data = request.get_json()
    resp = dbop.place_bet(session['user_id'], data)
    return jsonify(resp)

@app.route('/get_leaderboard_ajax', methods=['POST'])
def leaderboard_ajax():
    data = request.get_json()
    resp = dbop.leaderboard(data)
    return jsonify(resp)

@app.route('/verify_can_bet_ajax', methods=['POST'])
def verify_can_bet():
    data = request.get_json()
    resp = dbop.verify_can_bet(session['user_id'], data)
    return jsonify(resp)
if __name__ == "__main__":
    app.run(debug=True)
